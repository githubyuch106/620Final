class Publisher < ApplicationRecord
	belongs_to :book
end
