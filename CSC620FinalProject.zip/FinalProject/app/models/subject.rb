class Subject < ApplicationRecord
	belongs_to :book
end
