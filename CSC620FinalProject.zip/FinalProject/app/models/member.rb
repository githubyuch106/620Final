class Member < ApplicationRecord
	has_many :checkouts
end
