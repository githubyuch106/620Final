class Checkout < ApplicationRecord
	belongs_to :member
end
