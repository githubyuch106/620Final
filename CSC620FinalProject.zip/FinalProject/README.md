# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

- change your database credential to your root folder.
- my root@localhost doesn't have password, but you might.
- You need to run: 
    bundle install
    rake db:create
    rake db:migrate
    rails server
